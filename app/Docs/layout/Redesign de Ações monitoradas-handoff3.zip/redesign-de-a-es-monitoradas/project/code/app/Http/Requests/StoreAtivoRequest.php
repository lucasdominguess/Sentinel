<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreAtivoRequest extends FormRequest
{
    protected function prepareForValidation(): void
    {
        $t = strtoupper(trim((string) $this->input('ticker')));
        $t = preg_replace('/\.SA$/', '', $t);
        $this->merge(['ticker' => preg_replace('/[^A-Z0-9]/', '', $t)]);
    }

    public function rules(): array
    {
        return [
            'ticker' => ['required', 'regex:/^[A-Z]{4}\d{1,2}$/', Rule::unique('ativos', 'ticker')],
            'tipo' => ['required', Rule::in(['acao', 'fii', 'etf'])],
        ];
    }

    public function messages(): array
    {
        return [
            'ticker.required' => 'Informe o ticker.',
            'ticker.regex' => 'Formato inválido. Use 4 letras + 1–2 dígitos (ex.: VALE3, HGLG11).',
            'ticker.unique' => ':input.SA já está no cadastro.',
        ];
    }
}

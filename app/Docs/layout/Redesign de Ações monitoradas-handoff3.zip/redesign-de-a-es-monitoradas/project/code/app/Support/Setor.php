<?php

namespace App\Support;

final class Setor
{
    private const PT = [
        'Technology' => 'Tecnologia',
        'Consumer Cyclical' => 'Consumo cíclico',
        'Consumer Defensive' => 'Consumo não cíclico',
        'Utilities' => 'Utilidade pública',
        'Financial Services' => 'Financeiro',
        'Real Estate' => 'Imobiliário',
        'Basic Materials' => 'Materiais básicos',
        'Energy' => 'Petróleo e gás',
        'Industrials' => 'Bens industriais',
        'Healthcare' => 'Saúde',
        'Communication Services' => 'Comunicações',
    ];

    public static function pt(?string $en): string
    {
        return $en ? (self::PT[$en] ?? $en) : '—';
    }
}

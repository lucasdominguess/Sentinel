{{-- POST cadastro.store usa App\Http\Requests\StoreAtivoRequest; em sucesso: redirect()->route('cadastro.index')->with('novo', $ticker) --}}
@extends('layouts.app')
@section('title', 'Adicionar ticket · Sentinel')

@section('content')
@php
  $tipos = ['acao' => ['Ação', 'Empresas listadas'], 'fii' => ['FII', 'Fundos imobiliários'], 'etf' => ['ETF', 'Fundos de índice']];
  $tipoAtual = old('tipo', 'acao');
  $erro = $errors->first('ticker');
@endphp

<nav class="breadcrumb" aria-label="Trilha">
  <a href="{{ route('cadastro.index') }}"><span aria-hidden="true">←</span> Cadastro de ativos</a>
  <span aria-hidden="true">/</span>
  <span aria-current="page">Adicionar ticket</span>
</nav>

<section class="page-header" style="margin-top:var(--space-4)">
  <div class="page-header__title">
    <span class="kicker">Gestão · Cadastro</span>
    <h1 class="h1">Adicionar ticket</h1>
    <p class="page-header__lead">O ativo entra na lista de monitorados; a cotação é buscada no próximo update do coletor.</p>
  </div>
</section>

<div class="add-layout">
  <form class="card form-card" method="POST" action="{{ route('cadastro.store') }}" novalidate data-add-form>
    @csrf
    <div class="form-card__body">
      <div class="field">
        <label class="field__label" for="ticker">Ticker</label>
        <div class="input-affix">
          <input class="input input--lg" id="ticker" name="ticker" value="{{ old('ticker') }}" placeholder="VALE3"
                 autocomplete="off" autocapitalize="characters" spellcheck="false" required maxlength="9"
                 aria-describedby="ticker-msg" @if($erro) aria-invalid="true" @endif data-ticker-input>
          <span class="input-affix__suffix" aria-hidden="true">.SA</span>
        </div>
        <span id="ticker-msg" class="{{ $erro ? 'field__error' : 'field__help' }}" aria-live="polite" data-ticker-msg>
          {{ $erro ?: 'Código da B3. O sufixo .SA é adicionado automaticamente.' }}
        </span>
      </div>

      <fieldset class="field">
        <legend>Tipo</legend>
        <div class="choices">
          @foreach ($tipos as $k => [$label, $hint])
            <label class="choice">
              <input type="radio" name="tipo" value="{{ $k }}" @checked($tipoAtual === $k)>
              <span class="choice__title">{{ $label }}</span>
              <span class="choice__hint">{{ $hint }}</span>
            </label>
          @endforeach
        </div>
        <span class="field__help" data-tipo-hint hidden>Tickers terminados em 11 costumam ser FII, ETF ou unit. Confira o tipo.</span>
      </fieldset>
    </div>
    <div class="form-card__actions">
      <a class="btn btn-ghost" href="{{ route('cadastro.index') }}">Cancelar</a>
      <button class="btn btn-primary" type="submit" data-submit>Adicionar</button>
    </div>
  </form>

  <aside class="preview" aria-label="Prévia">
    <span class="label">Prévia no cadastro</span>
    <div class="preview__card">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
        <span class="ticker"><span data-preview-ticker>VALE3</span><small>.SA</small></span>
        <span class="tag tag--class" data-preview-tipo>Ação</span>
      </div>
      <x-status status="aguardando" />
      <p>Nome e setor são preenchidos pelo coletor junto com a primeira cotação.</p>
    </div>
  </aside>
</div>

<script>
  (() => {
    const form = document.querySelector('[data-add-form]');
    const input = form.querySelector('[data-ticker-input]');
    const msg = form.querySelector('[data-ticker-msg]');
    const hint = form.querySelector('[data-tipo-hint]');
    const submit = form.querySelector('[data-submit]');
    const pvT = document.querySelector('[data-preview-ticker]');
    const pvTipo = document.querySelector('[data-preview-tipo]');
    const HELP = 'Código da B3. O sufixo .SA é adicionado automaticamente.';
    const re = /^[A-Z]{4}\d{1,2}$/;
    const norm = v => v.toUpperCase().replace(/\.SA$/, '').replace(/[^A-Z0-9]/g, '');
    const tipo = () => form.querySelector('input[name="tipo"]:checked');
    let tried = false;

    const render = () => {
      const t = norm(input.value), ok = re.test(t);
      const bad = (tried && !t) || ((tried || t.length >= 6) && t && !ok);
      input.toggleAttribute('aria-invalid', bad);
      if (bad) input.setAttribute('aria-invalid', 'true');
      msg.className = bad ? 'field__error' : ok ? 'field__help field__help--ok' : 'field__help';
      msg.textContent = bad ? (t ? 'Formato inválido. Use 4 letras + 1–2 dígitos (ex.: VALE3, HGLG11).' : 'Informe o ticker.')
                       : ok ? `${t}.SA · formato válido` : HELP;
      submit.setAttribute('aria-disabled', ok ? 'false' : 'true');
      hint.hidden = !(/11$/.test(t) && tipo()?.value === 'acao');
      pvT.textContent = t || 'VALE3';
      pvTipo.textContent = tipo()?.closest('.choice').querySelector('.choice__title').textContent ?? 'Ação';
    };
    input.addEventListener('input', () => { const p = input.selectionStart; input.value = input.value.toUpperCase(); input.setSelectionRange(p, p); render(); });
    form.addEventListener('change', render);
    form.addEventListener('submit', e => { tried = true; if (!re.test(norm(input.value))) { e.preventDefault(); render(); input.focus(); } else { input.value = norm(input.value); } });
    if (!input.hasAttribute('aria-invalid')) render();
  })();
</script>
@endsection

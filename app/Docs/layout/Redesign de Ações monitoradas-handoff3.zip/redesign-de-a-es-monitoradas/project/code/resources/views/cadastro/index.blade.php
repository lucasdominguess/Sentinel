{{--
  $ativos   LengthAwarePaginator|Collection de: ticker, nome, setor (EN), tipo ('acao'|'fii'|'etf'), status ('ativo'|'pausado'|'erro'|'aguardando')
  $total    int     $tipo 'todos'|'acao'|'fii'|'etf'     $q string     $ordem 'ticker'|'nome'|'setor'     $dir 'asc'|'desc'
  session('novo') ticker recém-adicionado (flash)
--}}
@extends('layouts.app')
@section('title', 'Cadastro de ativos · Sentinel')

@section('content')
@php
  use App\Support\Setor;
  $tipos = ['todos' => 'Todos', 'acao' => 'Ações', 'fii' => 'FIIs', 'etf' => 'ETFs'];
  $tipoLabel = ['acao' => 'Ação', 'fii' => 'FII', 'etf' => 'ETF'];
  $qs = fn (array $p) => request()->fullUrlWithQuery($p);
  $sortLink = function ($col) use ($ordem, $dir, $qs) {
      $next = $ordem === $col && $dir === 'asc' ? 'desc' : 'asc';
      return $qs(['ordem' => $col, 'dir' => $next]);
  };
  $ariaSort = fn ($col) => $ordem === $col ? ($dir === 'asc' ? 'ascending' : 'descending') : 'none';
  $novo = session('novo');
@endphp

<section class="page-header">
  <div class="page-header__title">
    <span class="kicker">Gestão · Cadastro</span>
    <h1 class="h1">Cadastro de ativos</h1>
    <p class="page-header__lead">{{ $total }} ativo(s) cadastrado(s). Gerencie os ativos monitorados.</p>
  </div>
  <div class="page-header__actions">
    <a class="btn btn-primary" href="{{ route('cadastro.create') }}"><span aria-hidden="true">+</span> Adicionar ticket</a>
  </div>
</section>

@if ($novo)
  <div class="alert alert--success" role="status">
    <span class="alert__icon" aria-hidden="true">✓</span>
    <p><strong>{{ $novo }}.SA adicionado.</strong> <span class="tone-flat">A cotação é buscada no próximo update do coletor.</span></p>
  </div>
@endif

<div class="toolbar">
  <nav class="seg" aria-label="Filtrar por tipo">
    @foreach ($tipos as $k => $label)
      <a href="{{ $qs(['tipo' => $k, 'page' => null]) }}" @if($tipo === $k) aria-current="true" @endif>{{ $label }}</a>
    @endforeach
  </nav>
  <div class="toolbar__end">
    <form class="search" role="search" method="GET">
      <input type="hidden" name="tipo" value="{{ $tipo }}">
      <svg class="search__icon" width="15" height="15" viewBox="0 0 16 16" aria-hidden="true"><circle cx="7" cy="7" r="5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M11 11l3.5 3.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      <input type="search" name="q" value="{{ $q }}" placeholder="Filtrar por ticker, nome ou setor…" aria-label="Filtrar ativos" autocomplete="off" data-filter>
      <kbd class="kbd" aria-hidden="true">/</kbd>
    </form>
  </div>
</div>

<p class="results-meta">Ordenado por {{ ['ticker' => 'ticker', 'nome' => 'nome', 'setor' => 'setor'][$ordem] }}</p>

@if ($ativos->isEmpty())
  <div class="empty">
    <h2>Nenhum ativo encontrado</h2>
    <p>Ajuste a busca ou o filtro de tipo.</p>
    <a class="btn btn-ghost" href="{{ route('cadastro.index') }}">Limpar filtros</a>
  </div>
@else
  <div class="table cadastro-table" role="table" aria-label="Ativos cadastrados">
    <div class="table__row table__head" role="row">
      <a class="table__th" role="columnheader" aria-sort="{{ $ariaSort('ticker') }}" href="{{ $sortLink('ticker') }}">Ticker</a>
      <a class="table__th" role="columnheader" aria-sort="{{ $ariaSort('nome') }}" href="{{ $sortLink('nome') }}">Nome</a>
      <a class="table__th" role="columnheader" aria-sort="{{ $ariaSort('setor') }}" href="{{ $sortLink('setor') }}">Setor</a>
      <span class="table__th table__th--static" role="columnheader">Tipo</span>
      <span class="table__th table__th--static" role="columnheader">Status</span>
      <span class="table__th table__th--static" role="columnheader" style="justify-self:end">Ações</span>
    </div>

    @foreach ($ativos as $a)
      <div class="table__row @if($novo === $a->ticker) is-new @endif" role="row" data-search="{{ \Illuminate\Support\Str::lower($a->ticker . ' ' . $a->nome . ' ' . $a->setor . ' ' . Setor::pt($a->setor)) }}">
        <span role="cell" data-col="ticker"><span class="ticker">{{ $a->ticker }}<small>.SA</small></span><span class="tag tag--class">{{ $tipoLabel[$a->tipo] }}</span></span>
        <span role="cell" data-col="nome" class="cell-trunc" title="{{ $a->nome }}">{{ $a->nome }}</span>
        <span role="cell" data-col="setor" class="cell-trunc tone-flat" title="{{ $a->setor }}">{{ Setor::pt($a->setor) }}</span>
        <span role="cell" data-col="tipo"><span class="tag tag--class">{{ $tipoLabel[$a->tipo] }}</span></span>
        <span role="cell" data-col="status"><x-status :status="$a->status" /></span>
        <span data-col="meta" aria-hidden="true"><x-status :status="$a->status" /> · {{ Setor::pt($a->setor) }}</span>
        <div role="cell" data-col="acoes" class="cell-end">
          <a class="btn btn-ghost btn--sm btn-detalhes" href="{{ route('cadastro.show', $a->ticker) }}">Detalhes</a>
          <details class="menu">
            <summary class="menu__trigger" aria-label="Mais ações para {{ $a->ticker }}">⋯</summary>
            <div class="menu__list" role="menu">
              <a class="menu__item" role="menuitem" href="{{ route('cadastro.show', $a->ticker) }}">Ver detalhes</a>
              <form method="POST" action="{{ route('cadastro.toggle', $a->ticker) }}">
                @csrf @method('PATCH')
                <button class="menu__item" role="menuitem">{{ $a->status === 'pausado' ? 'Retomar monitoramento' : 'Pausar monitoramento' }}</button>
              </form>
              <span class="menu__sep"></span>
              <button class="menu__item menu__item--danger" role="menuitem" type="button" data-confirm-remove="{{ $a->ticker }}">Remover do cadastro</button>
            </div>
          </details>
        </div>
      </div>
    @endforeach

    <div class="table__foot">
      <span>{{ $ativos->count() }} de {{ $total }}</span>
      @if (method_exists($ativos, 'nextPageUrl') && $ativos->nextPageUrl())
        <a class="btn btn-ghost btn--sm" href="{{ $ativos->nextPageUrl() }}">Carregar mais</a>
      @endif
    </div>
  </div>
@endif

<dialog class="dialog" id="confirm-remove" aria-labelledby="rm-title">
  <form method="POST" data-remove-form>
    @csrf @method('DELETE')
    <h2 id="rm-title">Remover <span data-remove-ticker></span>.SA?</h2>
    <p>O ativo deixa de ser monitorado e sai das listas de cotação. Você pode adicioná-lo de novo depois.</p>
    <div class="dialog__actions">
      <button class="btn btn-ghost" type="button" value="cancel" formmethod="dialog" autofocus>Cancelar</button>
      <button class="btn btn-danger" type="submit">Remover</button>
    </div>
  </form>
</dialog>

<script>
  (() => {
    const dlg = document.getElementById('confirm-remove');
    const form = dlg.querySelector('[data-remove-form]');
    const base = @json(url('cadastro'));
    document.querySelectorAll('[data-confirm-remove]').forEach(b => b.addEventListener('click', () => {
      const t = b.dataset.confirmRemove;
      dlg.querySelector('[data-remove-ticker]').textContent = t;
      form.action = `${base}/${encodeURIComponent(t)}`;
      b.closest('details')?.removeAttribute('open');
      dlg.showModal();
    }));
    dlg.querySelector('[value="cancel"]').addEventListener('click', () => dlg.close());
    // fecha menus abertos ao clicar fora / Esc
    document.addEventListener('click', e => document.querySelectorAll('details.menu[open]').forEach(d => !d.contains(e.target) && d.removeAttribute('open')));
    document.addEventListener('keydown', e => e.key === 'Escape' && document.querySelectorAll('details.menu[open]').forEach(d => d.removeAttribute('open')));
  })();
</script>
@endsection

@props(['status' => 'ativo'])
@php
  $labels = ['ativo' => 'Ativo', 'pausado' => 'Pausado', 'erro' => 'Sem cotação', 'aguardando' => 'Aguardando cotação'];
@endphp
<span {{ $attributes->merge(['class' => "status status--{$status}"]) }}>{{ $labels[$status] ?? $status }}</span>
